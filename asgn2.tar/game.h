#ifndef GAME_H
#define GAME_H

void game(struct tnode *);

#endif