#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "a2defs.h"
#include "tnode.h"


int main(int argc, char *argv[]){
    FILE *fp;
    int cnt = 0;
    struct tnode *tree = NULL;

    /* creates database file if one wasn't already created */
    if ((fp = fopen(QA, READ)) == NULL){
        printf("Unable to read database qa.db. Starting fresh.\n\n");
        fp = safeOpen(QA, APPENDP);
        safeClose(fp);
        printf("What is it (with article)? ");
        char *input = stringInput(stdin);
        input = rmNL(input);
        tree = (struct tnode*)createNode(input);
    }
    
    else{
        /* prevents memory leak when opening file */
        safeClose(fp);
        fp = safeOpen(QA, READ);
        tree = (struct tnode*)createTree(fp);
        checkValid(tree);
        game(tree);
        safeClose(fp);
    }
    
    fp = safeOpen(QA, WRITE);
    preorder(tree, fp, cnt);
    safeClose(fp);
    freeTree(tree);
    return 0;
}
